package compound;

public class Data {
	private Double Principal;
	private int nomber;
	private Double interest_rate;
	private Double time;
	private Double compound;
	private Double danli;
	
	public Double getDanli() {
		return danli;
	}


	public void setDanli(Double danli) {
		this.danli = danli;
	}


	public Double getPrincipal() {
		return Principal;
	}
	
	
	public void setPrincipal(Double principal) {
		Principal = principal;
	}
	
	
	public Double getInterest_rate() {
		return interest_rate;
	}
	public void setInterest_rate(Double interest_rate) {
		this.interest_rate = interest_rate;
	}
	public Double getTime() {
		return time;
	}
	public void setTime(Double time) {
		this.time = time;
	}
	
	
	public Double getCompound() {
		return compound;
	}
	
	
	public void setCompound(Double compound) {
		this.compound = compound;
	}


	public int getNomber() {
		return nomber;
	}


	public void setNomber(int nomber) {
		this.nomber = nomber;
	}

	

}
