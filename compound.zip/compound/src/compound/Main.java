package compound;

import java.sql.SQLException;
import java.util.List;

public class Main {

	public static void main(String[] args) throws SQLException {
		Data d = new Data();
		Data_model dm = new Data_model();
		/*d.setPrincipal(10);
		d.setInterest_rate(20);
		d.setTime(30);
		d.setCompound(40);
		dm.addRecord(d);
		*/
		//d.setNomber(1);
		//dm.delRecord(d);
		//List<Data> b = dm.getRecord();
		//for (Data data : b) {
			//System.out.println(data.getNomber()+","+data.getCompound()+","
			//		+data.getDanli());
			
		//}
	}

}
