package compound;

import javax.swing.JOptionPane;

public class testFunction {
	
	public int benjin(double i, double n, double F){
		
		
			
			
			
			double p = F/Math.pow((1+i),n);
			int a = (int) p;
			return a ;
			
			
		
		
	}
		

	public int fulijisuan(double i,double p, double n){
		double F=p*Math.pow((1+i),n);
		return (int) F;
		
	}
	public int lilv(double p, double n, double F){
		
		double i = (Math.pow(F/p,1/(n))-1);
		return (int) i;
	}

}
