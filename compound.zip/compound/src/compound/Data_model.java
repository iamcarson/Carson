package compound;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



public class  Data_model {
	
	public void addRecord(Data g) throws SQLException{
		Connection con = MainInterface1.getConnection();
		String sql = ""+"insert into compound"+"(nomber,principal,interest_rate,time,compound,danli)"+
					"values("+
					"?,?,?,?,?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1,g.getNomber());
		stmt.setDouble(2, g.getPrincipal());
		stmt.setDouble(3, g.getInterest_rate());
		stmt.setDouble(4, g.getTime());
		stmt.setDouble(5, g.getCompound());
		stmt.setDouble(6, g.getDanli());
		stmt.execute();
	}

	public List<Data> getRecord() throws SQLException{
		Connection con = MainInterface1.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from compound");
		List<Data> pd = new ArrayList<Data>();
		Data d = null;
		while (rs.next()) {
			d = new Data();
			d.setDanli(rs.getDouble("danli"));
			d.setInterest_rate(rs.getDouble("interest_rate"));
			d.setPrincipal(rs.getDouble("principal"));
			d.setTime(rs.getDouble("time"));
			d.setCompound(rs.getDouble("compound"));
			pd.add(d);
		}
	return pd;
		
	}
	public void delRecord(Data g) throws SQLException{
		Connection con = MainInterface1.getConnection();
		String sql = "delete from compound where nomber = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1,g.getNomber());
		stmt.execute();
	}
}
