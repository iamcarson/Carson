package compound;

import static org.junit.Assert.*;

import javax.swing.JOptionPane;

import org.junit.Test;

public class testFunctionTest {

	@Test
	public void testBenjin() {
		
		assertEquals(613,new testFunction().benjin(0.05, 10, 1000) );
	}
	@Test
	public void testfuli() {
		
		assertEquals(162,new testFunction().fulijisuan(0.05, 100, 10) );
	}

	
	

}
